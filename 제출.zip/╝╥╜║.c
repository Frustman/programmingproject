#include <windows.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void print_by_center(char arr[], int strlen, int y, int columns, int rows, WORD color);
void input_ch(int arr[], int y, int columns, int rows, int who_first, int ai_level);
void prt_checkboard(int arr[], int y, int columns, int rows, int size);
void computer_computer(int arr[], int columns, int rows, int ai_level, int counter_ai);

void print_by_center(char arr[], int strlen, int y, int columns, int rows, WORD color) {
	COORD coord = { columns / 2 - strlen / 2 , y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
	printf("%s", arr);
}

void prt_ui(int arr[], int columns, int rows, int who_first, int ai_level) {
	system("cls");

	print_by_center("### Tic-Tae-Toe ###", sizeof("### Tic-Tae-Toe ###") / sizeof(char), 2, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

	print_by_center("Player 1 : Human, Player 2 : Computer", sizeof("Player 1 : Human, Player 2 : Computer") / sizeof(char), 4, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

	prt_checkboard(arr, 6, columns, rows, 9);

	input_ch(arr, 23, columns, rows, who_first, ai_level);
}

void prt_wincom(int arr[], int columns, int rows, int win, int who_first, int ai_level) {
	print_by_center("### Tic-Tae-Toe ###", sizeof("### Tic-Tae-Toe ###") / sizeof(char), 2, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

	print_by_center("Player 1 : Computer, Player 2 : Computer", sizeof("Player 1 : Computer, Player 2 : Computer") / sizeof(char), 4, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

	prt_checkboard(arr, 6, columns, rows, 9);
	if (win == 1) {
		print_by_center("Player 1 win!", sizeof("Player 1 win!") / sizeof(char), 23, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	}
	else if (win == 0) {
		print_by_center("Player 2 win!", sizeof("Player 2 win!") / sizeof(char), 23, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	}
	else {
		print_by_center("Draw!", sizeof("Draw!") / sizeof(char), 23, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	}
	print_by_center("Try again? [Y/N] : ", sizeof("Try again? [Y/N] : ") / sizeof(char), 25, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	char c = '0';
	fgetc(stdin);
	scanf_s("%c", &c);
	if (c == 'N') {
		exit(1);
	}
	else if (c == 'Y') {
		for (int i = 0; i < 9; i++) {
			arr[i] = 0;
		}
		system("cls");
		computer_computer(arr, columns, rows, ai_level, rand() % 3 + 1);
	}
}

void prt_win(int arr[], int columns, int rows, int win, int who_first, int ai_level) {
	print_by_center("### Tic-Tae-Toe ###", sizeof("### Tic-Tae-Toe ###") / sizeof(char), 2, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

	print_by_center("Player 1 : Human, Player 2 : Computer", sizeof("Player 1 : Human, Player 2 : Computer") / sizeof(char), 4, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

	prt_checkboard(arr, 6, columns, rows, 9);
	if (win == 1) {
		print_by_center("Player 1 win!", sizeof("Player 1 win!") / sizeof(char), 23, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	}
	else if (win == 0) {
		print_by_center("Player 2 win!", sizeof("Player 2 win!") / sizeof(char), 23, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	}
	else {
		print_by_center("Draw!", sizeof("Draw!") / sizeof(char), 23, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	}
	print_by_center("Try again? [Y/N] : ", sizeof("Try again? [Y/N] : ") / sizeof(char), 25, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	char c = '0';
	fgetc(stdin);
	scanf_s("%c", &c);
	if (c == 'N') {
		exit(1);
	}
	else if (c == 'Y') {
		for (int i = 0; i < 9; i++) {
			arr[i] = 0;
		}
		system("cls");
		prt_ui(arr, columns, rows, who_first, ai_level);
	}
}



void prt_start(int arr[], int columns, int rows, int* ai_level) {
	print_by_center("### Tic-Tae-Toe ###", sizeof("### Tic-Tae-Toe ###") / sizeof(char), 5, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

	print_by_center("1 : Player first (X)    ", sizeof("1 : Player first (X)    ") / sizeof(char), 6, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	print_by_center("2 : Player second (O)   ", sizeof("2 : Player second (O)   ") / sizeof(char), 7, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	print_by_center("3 : Computer Vs Computer", sizeof("3 : Computer Vs Computer") / sizeof(char), 8, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	print_by_center("4 : Select AI           ", sizeof("4 : Select AI           ") / sizeof(char), 9, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	print_by_center("5 : Exit                ", sizeof("5 : Exit                ") / sizeof(char), 10, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	print_by_center("Enter command : ", sizeof("Enter command : ") / sizeof(char), 11, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	int d = 0;
	scanf_s("%d", &d);

	if (d == 1 || d == 2) {
		prt_ui(arr, columns, rows, d, *ai_level);
	}
	if (d == 3) {
		int k = rand() % 3 + 1;
		computer_computer(arr, columns, rows, *ai_level, k);
	}
	if (d == 4) {
		system("cls");
		print_by_center("### Select AI ###", sizeof("### Select AI ###") / sizeof(char), 5, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

		COORD coord = { columns / 2 - 9 , 6 };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
		char* ai_name[] = { "Dumber(Random)", "Dumb", "Smart" };
		printf("Current AI : %s", ai_name[*ai_level - 1]);
		print_by_center("1 : Dumber(Random)", sizeof("1 : Player first (X)    ") / sizeof(char), 9, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
		print_by_center("2 : Dumb          ", sizeof("2 : Player second (O)   ") / sizeof(char), 10, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
		print_by_center("3 : Smart         ", sizeof("3 : Computer Vs Computer") / sizeof(char), 11, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
		print_by_center("Enter command : ", sizeof("Enter command : ") / sizeof(char), 13, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
		scanf_s("%d", ai_level);
		if (*ai_level < 4 && *ai_level > 0) {
			system("cls");
			prt_start(arr, columns, rows, ai_level);
		}
		else {
			*ai_level = 1;
			system("cls");
			prt_start(arr, columns, rows, ai_level);
		}
	}
	else if (d == 5) {
		exit(1);
	}
	else {
		system("cls");
		prt_start(arr, columns, rows, ai_level);
	}
}

void prt_checkboard(int arr[], int y, int columns, int rows, int size) {
	for (int i = 0; i < size; i++) {
		int x = 15 - 10 * (i % 3);
		if (i % 3 == 2) x--;
		print_by_center("     ", x, y + 5 * (i / 3), columns, rows, (i % 2 == 0) ? BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE : BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_INTENSITY);
		print_by_center("     ", x, y + 1 + 5 * (i / 3), columns, rows, (i % 2 == 0) ? BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE : BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_INTENSITY);
		if (arr[i] == 0) print_by_center("     ", x, y + 2 + 5 * (i / 3), columns, rows, (i % 2 == 0) ? BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE : BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_INTENSITY);
		if (arr[i] == 2) print_by_center("  X  ", x, y + 2 + 5 * (i / 3), columns, rows, (i % 2 == 0) ? BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE : BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_INTENSITY);
		if (arr[i] == 1) print_by_center("  O  ", x, y + 2 + 5 * (i / 3), columns, rows, (i % 2 == 0) ? BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE : BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_INTENSITY);
		print_by_center("     ", x, y + 3 + 5 * (i / 3), columns, rows, (i % 2 == 0) ? BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE : BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_INTENSITY);
		print_by_center("     ", x, y + 4 + 5 * (i / 3), columns, rows, (i % 2 == 0) ? BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_BLUE : BACKGROUND_RED | BACKGROUND_GREEN | BACKGROUND_INTENSITY);
	}
}

void heuristics1(int arr[], int value) {
	if (arr[4] == 0) {
		arr[4] = value;
	}
	else if (arr[0] == 0 && arr[1] == 0 && arr[2] == 0 && arr[3] == 0 && arr[4] != 0 && arr[5] == 0 && arr[6] == 0 && arr[7] == 0 && arr[8] == 0) {
		arr[0] = value;
	}
	else {
		int cnt = 0;
		for (int i = 0; i < 9; i++) {
			if (arr[i] != 0) cnt++;
		}
		int arr2[9];
		for (int i = 0; i < 9; i++) {
			arr2[i] = arr[i] + 1;
		}
		int should = 0;
		for (int i = 0; i < 3; i++) {
			if (arr2[i * 3] * arr2[i * 3 + 1] * arr2[i * 3 + 2] == 4 || arr2[i * 3] * arr2[i * 3 + 1] * arr2[i * 3 + 2] == 9) {
				should = 100 * (i * 3) + 10 * (i * 3 + 1) + i * 3 + 2;
			}
			if (arr2[i] * arr2[i + 3] * arr2[i + 6] == 4 || arr2[i] * arr2[i + 3] * arr2[i + 6] == 9) {
				should = 100 * i + 10 * (i + 3) + i + 6;
			}
			if (arr2[i] * arr2[4] * arr2[8 - i] == 4 || arr2[i] * arr2[4] * arr2[8 - i] == 9) {
				should = 100 * i + 40 + 8 - i;
			}
		}
		if (should != 0) {
			if (arr[should / 100] == 0)
				arr[should / 100] = value;
			if (arr[(should % 100) / 10] == 0)
				arr[(should % 100) / 10] = value;
			if (arr[should % 10] == 0)
				arr[should % 10] = value;
		}
		else if (cnt == 2) {
			if (arr[0] == 0) arr[0] = value;
			else arr[2] = value;
		}
		else {
			int score[3][3] = { 0, };
			for (int i = 0; i < 9; i++) {
				if (arr[i] == 1) { // 1�̸� ��, 2�� ��ǻ�� ��. ���� �� ���̸� +1, ���� �� ���̸� -1
					if (arr2[(int)(i / 3) * 3] * arr2[(int)(i / 3) * 3 + 1] * arr2[(int)(i / 3) * 3 + 2] == (value == 2) ? 4 : 9) {
						score[i / 3][0] += 1000;
						score[i / 3][1] += 1000;
						score[i / 3][2] += 1000;
					}
					else if (arr2[(int)(i / 3) * 3] * arr2[(int)(i / 3) * 3 + 1] * arr2[(int)(i / 3) * 3 + 2] == (value == 2) ? 2 : 3) {
						score[i / 3][0] += 15;
						score[i / 3][1] += 15;
						score[i / 3][2] += 15;
					}
					if (arr2[i % 3] * arr2[3 + i % 3] * arr2[6 + i % 3] == (value == 2) ? 4 : 9) {
						score[0][i % 3] += 1000;
						score[1][i % 3] += 1000;
						score[2][i % 3] += 1000;
					}
					else if (arr2[i % 3] * arr2[3 + i % 3] * arr2[6 + i % 3] == (value == 2) ? 2 : 3) {
						score[0][i % 3] += 15;
						score[1][i % 3] += 15;
						score[2][i % 3] += 15;
					}
					if (i % 4 == 0) {
						if (arr2[0] * arr2[4] * arr2[8] != (value == 2) ? 2 : 3) score[0][0] += 15, score[1][1] += 15, score[2][2] += 15;
						else score[0][0] += 1000, score[1][1] += 1000, score[2][2] += 1000;
					}
					if (i % 2 == 1 && i != 0 && i != 9) {
						if (arr2[2] * arr2[4] * arr2[6] != (value == 2) ? 2 : 3) score[0][2] += 15, score[1][1] += 15, score[2][0] += 15;
						else score[0][2] += 1000, score[1][1] += 1000, score[2][0] += 1000;
					}
				}
				if (arr[i] == 2) { // 1�̸� ��, 2�� ��ǻ�� ��. ���� �� ���̸� +1, ���� �� ���̸� -1
					if (arr2[(int)(i / 3) * 3] * arr2[(int)(i / 3) * 3 + 1] * arr2[(int)(i / 3) * 3 + 2] == (value == 2) ? 9 : 4) {
						score[i / 3][0] += 100;
						score[i / 3][1] += 100;
						score[i / 3][2] += 100;
					}
					else if (arr2[(int)(i / 3) * 3] * arr2[(int)(i / 3) * 3 + 1] * arr2[(int)(i / 3) * 3 + 2] == (value == 2) ? 3 : 2) {
						score[i / 3][0] += 10;
						score[i / 3][1] += 10;
						score[i / 3][2] += 10;
					}
					if (arr2[i % 3] * arr2[3 + i % 3] * arr2[6 + i % 3] == (value == 2) ? 9 : 4) {
						score[0][i % 3] += 100;
						score[1][i % 3] += 100;
						score[2][i % 3] += 100;
					}
					else if (arr2[i % 3] * arr2[3 + i % 3] * arr2[6 + i % 3] == (value == 2) ? 3 : 2) {
						score[0][i % 3] += 10;
						score[1][i % 3] += 10;
						score[2][i % 3] += 10;
					}
					if (i % 4 == 0) {
						if (arr2[0] * arr2[4] * arr2[8] != (value == 2) ? 3 : 2) score[0][0] += 10, score[1][1] += 10, score[2][2] += 10;
						else score[0][0] += 100, score[1][1] += 100, score[2][2] += 100;
					}
					if (i % 2 == 1 && i != 0 && i != 9) {
						if (arr2[2] * arr2[4] * arr2[6] != (value == 2) ? 3 : 2) score[0][2] += 10, score[1][1] += 10, score[2][0] += 10;
						else score[0][2] += 100, score[1][1] += 100, score[2][0] += 100;
					}
				}
			}
			int max = -999999;
			int loc = 10;
			for (int i = 0; i < 9; i++) {
				if (score[i / 3][i % 3] >= max && arr[i] == 0) {
					max = score[i / 3][i % 3];
					loc = i;
				}
			}
			if (loc >= 0 && loc < 9) arr[loc] = value;
		}
	}
}

void dumb_ai(int arr[], int value) {
	int temp = 0, k = 0;
	if (arr[4] == 0) {
		arr[4] = value;
	}
	else {
		int arr2[9];
		for (int i = 0; i < 9; i++) {
			arr2[i] = arr[i] + 1;
		}
		int should = 0;
		for (int i = 0; i < 3; i++) {
			if (arr2[i * 3] * arr2[i * 3 + 1] * arr2[i * 3 + 2] == 4) {
				should = 100 * (i * 3) + 10 * (i * 3 + 1) + i * 3 + 2;
			}
			if (arr2[i] * arr2[i + 3] * arr2[i + 6] == 4) {
				should = 100 * i + 10 * (i + 3) + i + 6;
			}
			if (arr2[i] * arr2[4] * arr2[8 - i] == 4) {
				should = 100 * i + 40 + 8 - i;
			}
		}
		if (should != 0) {
			if (arr[should / 100] == 0)
				arr[should / 100] = value;
			if (arr[(should % 100) / 10] == 0)
				arr[(should % 100) / 10] = value;
			if (arr[should % 10] == 0)
				arr[should % 10] = value;
		}
		else if (arr[1] == 0 || arr[3] == 0 || arr[5] == 0 || arr[7] == 0) {
			k = rand() % 4;
			temp = 0;
			while (temp == 0) {
				if (arr[2 * k + 1] == 0) {
					arr[2 * k + 1] = value;
					temp++;
				}
				k = rand() % 4;
			}
		}
		else if (arr[0] == 0 || arr[2] == 0 || arr[6] == 0 || arr[8] == 0) {
			k = rand() % 4;
			temp = 0;
			while (temp == 0) {
				if (arr[2 * k] == 0) {
					arr[2 * k] = value;
					temp++;
				}
				k = rand() % 4;
			}
		}
	}
}

void dumber_ai(int arr[],int value) {
	int fin = 0;
	while (fin == 0) {
		int k = rand() % 9;
		if (arr[k] == 0) {
			arr[k] = value;
			fin = 1;
		}
	}
}

void computer_computer(int arr[], int columns, int rows, int ai_level, int counter_ai) {
	int fin = 0;
	while (fin == 0) {
		system("cls");
		print_by_center("### Tic-Tae-Toe ###", sizeof("### Tic-Tae-Toe ###") / sizeof(char), 2, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

		print_by_center("Player 1 : Computer, Player 2 : Computer", sizeof("Player 1 : Computer, Player 2 : Computer") / sizeof(char), 4, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

		prt_checkboard(arr, 6, columns, rows, 9);

		COORD coord = { columns / 2 - 7 , 25 };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
		char* ai_name[] = { "Dumber(Random)", "Dumb", "Smart" };
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
		printf("%s VS %s", ai_name[ai_level - 1], ai_name[counter_ai - 1]);

		if (arr[0] != 0 && arr[1] != 0 && arr[2] != 0 && arr[3] != 0 && arr[4] != 0 && arr[5] != 0 && arr[6] != 0 && arr[7] != 0 && arr[8] != 0 || who_win(arr) != 2) {
			system("cls");
			prt_wincom(arr, columns, rows, who_win(arr), 1, ai_level);
			fin = 1;
		}
		Sleep(500);

		if (ai_level == 1) dumber_ai(arr, 1);
		if (ai_level == 2) dumb_ai(arr, 1);
		if (ai_level == 3) heuristics1(arr, 1);

		if (arr[0] != 0 && arr[1] != 0 && arr[2] != 0 && arr[3] != 0 && arr[4] != 0 && arr[5] != 0 && arr[6] != 0 && arr[7] != 0 && arr[8] != 0 || who_win(arr) != 2) {
			system("cls");
			prt_wincom(arr, columns, rows, who_win(arr),1, ai_level);
			fin = 1;
		}

		system("cls");
		print_by_center("### Tic-Tae-Toe ###", sizeof("### Tic-Tae-Toe ###") / sizeof(char), 2, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

		print_by_center("Player 1 : Computer, Player 2 : Computer", sizeof("Player 1 : Computer, Player 2 : Computer") / sizeof(char), 4, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

		prt_checkboard(arr, 6, columns, rows, 9);

		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
		printf("%s VS %s", ai_name[ai_level - 1], ai_name[counter_ai - 1]);

		Sleep(500);

		if (counter_ai == 1) dumber_ai(arr, 2);
		if (counter_ai == 2) dumb_ai(arr, 2);
		if (counter_ai == 3) heuristics1(arr, 2);
	}
}

void input_ch(int arr[], int y, int columns, int rows, int who_first, int ai_level) {
	int a;
	print_by_center("Enter again :   ", sizeof("Enter again :   ") / sizeof(char), y, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
	int fin = 0, mistake = 0;
	while (fin == 0) {
		if (who_first == 2 && mistake == 0) {
			if (ai_level == 1) dumber_ai(arr, 2);
			if (ai_level == 2) dumb_ai(arr, 2);
			if (ai_level == 3) heuristics1(arr, 2);
			system("cls");
			print_by_center("### Tic-Tae-Toe ###", sizeof("### Tic-Tae-Toe ###") / sizeof(char), 2, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

			print_by_center("Player 1 : Human, Player 2 : Computer", sizeof("Player 1 : Human, Player 2 : Computer") / sizeof(char), 4, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

			prt_checkboard(arr, 6, columns, rows, 9);

			print_by_center("Enter again :   ", sizeof("Enter again :   ") / sizeof(char), y, columns, rows, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
		}
		if (arr[0] != 0 && arr[1] != 0 && arr[2] != 0 && arr[3] != 0 && arr[4] != 0 && arr[5] != 0 && arr[6] != 0 && arr[7] != 0 && arr[8] != 0 || who_win(arr) != 2) {
			system("cls");
			prt_win(arr, columns, rows, who_win(arr), who_first, ai_level);
			fin = 1;
		}
		else if (arr[0] != 0 && arr[1] != 0 && arr[2] != 0 && arr[3] != 0 && arr[4] != 0 && arr[5] != 0 && arr[6] != 0 && arr[7] != 0 && arr[8] != 0 && who_win(arr) == 2) {
			system("cls");
			prt_win(arr, columns, rows, who_win(arr), who_first, ai_level);
			fin = 1;
		}
		scanf_s("%d", &a);
		if (a <= 9 && a > 0 && arr[a - 1] == 0) {
			if (arr[0] != 0 && arr[1] != 0 && arr[2] != 0 && arr[3] != 0 && arr[4] != 0 && arr[5] != 0 && arr[6] != 0 && arr[7] != 0 && arr[8] != 0 || who_win(arr) != 2) {
				system("cls");
				prt_win(arr, columns, rows, who_win(arr), who_first, ai_level);
				fin = 1;
			}
			else if (arr[0] != 0 && arr[1] != 0 && arr[2] != 0 && arr[3] != 0 && arr[4] != 0 && arr[5] != 0 && arr[6] != 0 && arr[7] != 0 && arr[8] != 0 && who_win(arr) == 2) {
				system("cls");
				prt_win(arr, columns, rows, who_win(arr), who_first, ai_level);
				fin = 1;
			}
			else {
				arr[a - 1] = 1;
				if (who_first == 1) {
					if (ai_level == 1) dumber_ai(arr, 2);
					if (ai_level == 2) dumb_ai(arr, 2);
					if (ai_level == 3) heuristics1(arr, 2);
				}
				system("cls");
				prt_ui(arr, columns, rows, who_first, ai_level);
			}
			mistake = 0;
		}
		else {
			system("cls");
			prt_ui(arr, columns, rows, who_first, ai_level);
			mistake = 1;
		}
	}
}


int who_win(int arr[]) {
	for (int i = 0; i < 3; i++) {
		if (arr[i * 3] * arr[i * 3 + 1] * arr[i * 3 + 2] == 1) {
			return 1; // player win
		}
		else if (arr[i * 3] * arr[i * 3 + 1] * arr[i * 3 + 2] == 8) {
			return 0; // cp win
		}

		if (arr[i] * arr[i + 3] * arr[i + 6] == 1) {
			return 1; // player win
		}
		else if (arr[i] * arr[i + 3] * arr[i + 6] == 8) {
			return 0; // cp win
		}

		if (arr[i] * arr[4] * arr[8 - i] == 1) {
			return 1; // player win
		}
		else if (arr[i] * arr[4] * arr[8 - i] == 8) {
			return 0; // cp win
		}
	}
	return 2;
}


int main() {
	srand((unsigned int)time(NULL));
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	int columns, rows;
	GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);
	columns = csbi.srWindow.Right - csbi.srWindow.Left + 1;
	rows = csbi.srWindow.Bottom - csbi.srWindow.Top + 1;
	int arr[9] = { 0, };
	int ai_level = 1;

	prt_start(arr, columns, rows, &ai_level);
}
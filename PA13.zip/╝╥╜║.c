#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <Windows.h>
#include <time.h> 
#define MAX_STR 255


typedef struct struct_word {
	char word[MAX_STR];
	char meaning[MAX_STR];
} Sword;

typedef struct answer_set {
	int count;
} Aset;

void input_pt(FILE *fp, Sword* dict, Aset* aset, int count);
void prt_ui(FILE *fp, Sword* dict, Aset* aset, int count);

void file_input(FILE *fp, Sword* dict) {
	char delimiter[] = " \t";
	char *token, *temp;
	int count = 0;
	char buff[255];
	fseek(fp, 0L, SEEK_SET);
	while (fgets(buff, 100, fp) > 0) {
		token = strtok(buff, delimiter);
		strcpy(dict[count].word, token);
		temp = &token[strlen(token) + 1];
		while (temp[0] == ' ' || temp[0] == '\t') {
			temp++;
		}
		strcpy(dict[count].meaning, temp);
		count++;
	}
}

int strcmp_ignore_case(char* a, char* b) {
	int i = 0;
	char cmp1, cmp2;
	while (a[i] != 0) {
		if (a[i] >= 'A' && a[i] <= 'Z') {
			cmp1 = a[i] + abs('A' - 'a');
		}
		else cmp1 = a[i];
		if (b[i] >= 'A' && b[i] <= 'Z') {
			cmp2 = b[i] + abs('A' - 'a');
		}
		else cmp2 = b[i];
		if (cmp1 == cmp2) {
			i++;
		}
		else {
			return 1;
		}
	}
	return 0;
}

int real_rand(Aset* aset, int count) {
	int r_count = count;
	for (int i = 0; i < count; i++) {
		r_count += aset[i].count;
	}
	int k = rand() % r_count, cursor = 0;
	for (int i = 0; i < count; i++) {
		if (k >= cursor && k <= cursor + aset[i].count) return i;
		cursor += aset[i].count + 1;
	}
}

void word_game(FILE *fp, Sword* dict, Aset* aset, int count) {
	int random[20], k = 0, mu_cnt = 0, temp = 0;
	int ans_count[10];
	for (int i = 0; i < 20; )
	{
		int j;
		random[i] = real_rand(aset, count);
		
		for (j = 0; j < i; j++) if (random[j] == random[i]) break;
		if (j >= i) i++;
	}
	for (int j = 0; j < 10; j++) {
		int index_set[4], index[4];
		for (int i = 0; i < 4; )
		{
			int y;
			index_set[i] = rand() % 10;
			for (y = 0; y < i; y++) if (index_set[y] == index_set[i]) break;
			if (y >= i) i++;
		}
		for (int i = 0; i < 4; )
		{
			int y;
			index[i] = rand() % 4;
			for (y = 0; y < i; y++) if (index[y] == index[i]) break;
			if (y >= i) i++;
		}
		printf("%d. %s\n", j + 1, dict[random[index_set[0]]].word);
		for (int i = 0; i < 4; i++) {
			printf("	%c. %s", 'a' + i, dict[random[index_set[index[i]]]].meaning);
		}
		printf("Enter : ");
		char ans = 'f';
		while (ans < 'a' || ans > 'd') {
			while (getchar() != '\n');
			scanf("%c", &ans);
			if (ans >= 'a' && ans <= 'd') {
				if (index_set[index[ans - 'a']] != index_set[0]) aset[random[index_set[0]]].count++, ans_count[temp] = random[index_set[0]], temp++;
				if (index_set[index[ans - 'a']] == index_set[0]) ans_count[temp] = 0, temp++;
			}
			else {
				printf("Enter again : ");
			}
		}
	}
	int score = 0;
	for (int i = 0; i < 10; i++) {
		if (ans_count[i] == 0) score += 50;
	}
	printf("\nScore : %d (correct %d out of 10 problems)\n\nWrong Problems\n\n", score, score / 50);
	for (int i = 0; i < 10; i++) {
		if (ans_count[i] != 0) printf("%d. %s %s", i + 1, dict[ans_count[i]].word, dict[ans_count[i]].meaning);
	}

	FILE* fpout = fopen("wordset_out", "wb");
	if (fpout == NULL) {
		printf("\n\n���� ���� ����.\n");
		exit(1);
	}
	for (int i = 0; i < count; i++) {
		fwrite(aset + i, sizeof(Aset), 1, fpout);
	}
	fclose(fpout);
}


void input_pt(FILE *fp, Sword* dict, Aset* aset, int count) {
	int input_d, loc = 0;
	do {
		scanf("%d", &input_d);
		if (input_d < 1 || input_d > 3) {
			printf("\n�߸� �Է��ϼ̽��ϴ�. �ٽ� �Է����ּ���.");
		}
	} while (input_d < 1 || input_d > 3);
	if (input_d == 1) {
		char buff[255];
		printf("\nã���� �Ͻô� �ܾ �Է����ּ���. ");
		while (getchar() != '\n');
		scanf("%s", buff);
		int found = 0;
		for (int i = 0; i < count; i++) {
			if (strcmp_ignore_case(buff, dict[i].word) == 0) {
				printf("\n\n �ܾ� : %s, �ǹ� : %s", dict[i].word, dict[i].meaning);
				printf("\n�ٸ� �ܾ ã�� ��ʴϱ�? [Y/N] : ");
				while (getchar() != '\n');
				char yorn;
				scanf("%c", &yorn);
				if (yorn == 'N') {
					found = 2;
					break;
				}
				found = 1;
			}
		}
		if (found == 0) {
			printf("�׷� �ܾ Ȯ���� �� �����ϴ�.");
		}
		if (found == 1) {
			printf("�� �̻� �ܾ Ȯ���� �� �����ϴ�.");
		}
	}
	if (input_d == 2) {
		char select = 'a';
		while (select != 'f') {
			for (int i = loc; i < loc + 15; i++) {
				printf("�ܾ� : %s, �ǹ� : %s", dict[i].word, dict[i].meaning);
			}
			printf("\n\n ���� ������ : n, ���� ������ : p, �޴��� ������ : f\nEnter : ");
			while (getchar() != '\n');
			scanf("%c", &select);
			if (select == 'n') {
				if (loc + 15 < count) loc += 15;
				else printf("���� �������� �����ϴ�."), Sleep(100);
			}
			if (select == 'p') {
				if (loc - 15 > 0) loc -= 15;
				else printf("���� �������� �����ϴ�."), Sleep(100);
			}
		}
		prt_ui(fp, dict, aset, count);
	}
	if (input_d == 3) {
		word_game(fp, dict, aset, count);
	}
	if (input_d == 4) {
		exit(1);
	}
}

void prt_ui(FILE *fp, Sword* dict, Aset* aset,  int count) {
	printf(" ### Dictionary ###\n");
	printf("1. Search a Word\n");
	printf("2. List words\n");
	printf("3. Word Game - Find Meaning\n");
	printf("4. Exit\n");
	input_pt(fp, dict, aset, count);
}


int main() {
	srand((unsigned int)time(NULL));
	FILE *fp;
	fp = fopen("voca13000.txt", "r");
	FILE* fpin = fopen("wordset_in", "rb+");
	if (fp == NULL || fpin == NULL) {
		printf("���� ���� ����\n");
		exit(-1);
	}

	char buff[255];
	int cnt = 0;
	while (fgets(buff, 100, fp) > 0) cnt++;

	Sword* dict;
	dict = (Sword*)malloc(cnt * sizeof(Sword));

	Aset* aset;
	aset = (Aset*)malloc(cnt * sizeof(Aset));

	for (int i = 0; i < cnt; i++) {
		aset[i].count = 0;
	}

	Aset aset_buff;
	aset_buff.count = 0;
	int k = 0;

	while (fread(&aset_buff, sizeof(Aset), 1, fpin) > 0) {
		aset[k].count = aset_buff.count;
		k++;
	}

	file_input(fp, dict);
	prt_ui(fp, dict, aset, cnt);
}